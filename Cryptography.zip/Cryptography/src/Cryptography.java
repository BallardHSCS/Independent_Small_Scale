public class Cryptography
{
    private int rotations = 13;  // used in the second part

    public Cryptography()
    {
        // no need to put anything here for now.
    }

    public int convertToNumbers(char letter)
    {
        // fill in this method!
        return 0;
    }

    // create a similar method for the ROT13 portion.
    // This method will return a character instead.
}
